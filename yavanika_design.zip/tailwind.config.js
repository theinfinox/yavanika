/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{html,js}", "./!(build|dist|.*)/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        white: "#fff",
      },
      fontFamily: {
        inter: "Inter",
        "crimson-pro": "'Crimson Pro'",
      },
    },
    fontSize: {
      "5xl-9": "1.56rem",
      "xl-3": "1.27rem",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
